FLOATING AI TUTOR - ANDROID SOURCE PROJECT

This is source code, not a prebuilt APK. It has not been compiled or tested on your phone.

FEATURES
- Movable floating panel approximately 3 cm x 5 cm (113dp x 189dp at mdpi).
- Tap-to-capture using Android's official screen-capture consent prompt.
- Sends the approved screenshot to your Cloudflare Worker and displays its answer.
- Android 10+ (API 29+).

BUILD ON ANDROID
1. Install AndroidIDE on your phone and open/import this project folder.
2. Use JDK 17 and Android Gradle Plugin 8.7.3; allow Gradle to sync.
3. Build an APK from the AndroidIDE build menu.
4. Install the APK.

CLOUDFLARE SETUP
1. Keep OPENAI_API_KEY as a Cloudflare Secret.
2. Add another Cloudflare Secret named TUTOR_ACCESS_TOKEN with a long random value.
3. The Worker must check Authorization: Bearer <TUTOR_ACCESS_TOKEN>, accept JSON fields question and image, and return JSON {success:true, answer:"..."}.
4. The app's connection screen needs the Worker URL and the same tutor access token.

APP SETUP
1. Open the app.
2. Enter your Worker URL and TUTOR_ACCESS_TOKEN value. Never enter your OpenAI API key in the app.
3. Save connection.
4. Enable floating tutor and grant Display over other apps permission.
5. Tap TAP TO CAPTURE and approve Android's screen-capture prompt each time.

SECURITY AND PRIVACY
- The app never receives your OpenAI API key.
- It stores the separate tutor access token in private app preferences.
- Only capture screens you intend to send to the AI service.
- Add Worker rate limiting and stronger authentication before public use.
- Android shows a screen-capture consent prompt; this app does not secretly capture screens.

KNOWN LIMITATIONS
- Android manufacturers may restrict floating overlays or background activity.
- This is a starter implementation; test on your device before relying on it.
- The Worker model name must be a model actually available to your OpenAI API project.
