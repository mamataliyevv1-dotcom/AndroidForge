package com.example.floatingaitutor

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var endpoint: EditText
    private lateinit var token: EditText
    private val prefs by lazy { getSharedPreferences("tutor_config", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        layout.addView(TextView(this).apply { text = "Floating AI Tutor"; textSize = 26f })
        layout.addView(TextView(this).apply {
            text = "Enter your Cloudflare Worker URL and private tutor access token. Do not enter your OpenAI API key here."
            textSize = 14f
            setPadding(0, 12, 0, 18)
        })
        endpoint = EditText(this).apply {
            hint = "https://your-worker.workers.dev"
            setSingleLine(true)
            setText(prefs.getString("endpoint", ""))
        }
        layout.addView(endpoint)
        token = EditText(this).apply {
            hint = "Tutor access token"
            setSingleLine(true)
            inputType = 129
            setText(prefs.getString("token", ""))
        }
        layout.addView(token)
        layout.addView(Button(this).apply {
            text = "Save connection"
            setOnClickListener {
                saveConfig()
                Toast.makeText(this@MainActivity, "Connection details saved.", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(Button(this).apply {
            text = "Enable floating tutor"
            setOnClickListener {
                saveConfig()
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, FloatingOverlayService::class.java))
                    Toast.makeText(this@MainActivity, "Floating tutor enabled.", Toast.LENGTH_LONG).show()
                }
            }
        })
        layout.addView(TextView(this).apply {
            text = "Usage: leave this app, tap the floating panel, approve Android's screen-capture prompt, then wait for the explanation. Android asks for capture permission each time."
            textSize = 13f
            setPadding(0, 18, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun saveConfig() {
        prefs.edit().putString("endpoint", endpoint.text.toString().trim().trimEnd('/'))
            .putString("token", token.text.toString().trim()).apply()
    }
}
