FLOATING AI TUTOR - ANDROID SOURCE PROJECT
Version 1.1 release preparation

PROJECT
- Package ID: com.example.floatingaitutor
- Android 10+ (API 29+), JDK 17, Android Gradle Plugin 8.7.3
- Debug APK is for local device/UI testing.
- Release AAB requires an owner-created upload keystore and Play Console setup.

INCLUDED IN THIS SOURCE
- AES-GCM encrypted Worker URL and tutor token using Android Keystore.
- Migration and deletion of old plaintext SharedPreferences values.
- HTTPS-only endpoint validation; cleartext traffic disabled.
- Play Integrity standard-token client. Each request includes integrityToken and integrityRequestHash.
- Google Play immediate in-app update flow.
- Release signing configuration using environment variables.
- Version code 2 / version name 1.1.
- GitHub Actions workflow for debug APK and signed release AAB.

CRITICAL: BACKEND VERIFICATION IS STILL REQUIRED
The Android app now sends integrityToken and integrityRequestHash. The Cloudflare Worker MUST:
1. Receive the integrity token and hash.
2. Call Google's Play Integrity decodeIntegrityToken API server-side.
3. Verify packageName is com.example.floatingaitutor.
4. Verify requestDetails.requestHash equals SHA-256(question + newline + image), lowercase hex.
5. Verify appIntegrity.appRecognitionVerdict is PLAY_RECOGNIZED.
6. Apply an explicit device/account verdict policy.
7. Reject missing, invalid, mismatched, or unacceptable verdicts.
Never trust a token decoded only on the Android client.
The Cloudflare Worker source was not in the supplied archive, so this backend work is NOT completed by this Android patch.

PLAY INTEGRITY SETUP
- Create/select a Google Cloud project and enable Play Integrity API.
- Link the project to the app in Play Console.
- Set PLAY_INTEGRITY_CLOUD_PROJECT_NUMBER to the numeric project number.
- Debug builds allow local sideload testing without Integrity. Release builds require a configured project number.
- Play-recognition verdicts require an eligible Play-distributed install; sideloaded builds are not equivalent.
Official setup: https://developer.android.com/google/play/integrity/setup
Standard request guide: https://developer.android.com/google/play/integrity/standard

GOOGLE PLAY IN-APP UPDATES
- Uses Play Core app-update 2.1.0 immediate update flow.
- Works only when installed from Google Play and an eligible newer Play release exists.
- Sideloaded APKs do not update through Play In-App Updates.
Official guide: https://developer.android.com/guide/playcore/in-app-updates/kotlin-java

UPLOAD SIGNING
Never commit or share the keystore or passwords.
Create an upload key locally:
  keytool -genkeypair -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias floatingaitutor-upload

Set these variables for a signed release:
  UPLOAD_STORE_FILE=/absolute/path/upload-keystore.jks
  UPLOAD_STORE_PASSWORD=...
  UPLOAD_KEY_ALIAS=floatingaitutor-upload
  UPLOAD_KEY_PASSWORD=...
  PLAY_INTEGRITY_CLOUD_PROJECT_NUMBER=123456789012

For GitHub Actions configure:
- Secret ANDROID_KEYSTORE_BASE64 (base64 contents of your JKS file)
- Secret ANDROID_KEYSTORE_PASSWORD
- Secret ANDROID_KEY_ALIAS
- Secret ANDROID_KEY_PASSWORD
- Variable PLAY_INTEGRITY_CLOUD_PROJECT_NUMBER

The included workflow always builds a debug APK. It builds a signed AAB only when repository variable RELEASE_SIGNING_CONFIGURED is set to true and all signing secrets exist.
Official signing guide: https://developer.android.com/studio/publish/app-signing

INSTALLATION NOTES
- First install the debug APK to test UI, overlay permission and screen capture.
- Before updating an existing installation, verify package ID and signing certificate compatibility. Android will reject an update signed with a different key.
- Do not uninstall the current app until its signing identity is checked.
- Play Integrity enforcement and Play In-App Updates need a Play-distributed release and backend verification; they cannot be fully tested with a sideloaded debug APK.

CLOUDFLARE
- Keep OPENAI_API_KEY and TUTOR_ACCESS_TOKEN as separate Cloudflare secrets.
- Continue using Authorization: Bearer <TUTOR_ACCESS_TOKEN>.
- Update the Worker to verify Play Integrity before production use and add rate limits/request-size limits.

NOT VERIFIED HERE
This source has not been compiled, installed, tested against the actual Worker, or submitted to Play Console. Backend verification needs the Worker source and Google server authorization. Release signing needs the private upload keystore. Do not treat these steps as complete until the end-to-end checks pass.
