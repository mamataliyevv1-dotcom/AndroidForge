package com.example.floatingaitutor

import android.content.Context
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.PrepareIntegrityTokenRequest
import com.google.android.play.core.integrity.StandardIntegrityTokenRequest
import com.google.android.gms.tasks.Tasks

/**
 * Gets a standard Play Integrity token for one specific tutor request.
 * The Cloudflare Worker must decode and verify this token with Google's server API.
 */
class PlayIntegrityClient(context: Context) {
    private val appContext = context.applicationContext

    fun requestToken(requestHash: String): String? {
        require(requestHash.isNotBlank() && requestHash.length <= 500) {
            "Invalid Play Integrity request hash."
        }
        val projectNumber = BuildConfig.PLAY_INTEGRITY_CLOUD_PROJECT_NUMBER
        if (projectNumber <= 0L) {
            if (!BuildConfig.PLAY_INTEGRITY_REQUIRED) return null
            throw IllegalStateException("Play Integrity is not configured.")
        }
        val manager = IntegrityManagerFactory.createStandard(appContext)
        val provider = Tasks.await(
            manager.prepareIntegrityToken(
                PrepareIntegrityTokenRequest.builder()
                    .setCloudProjectNumber(projectNumber)
                    .build()
            )
        )
        return Tasks.await(
            provider.request(
                StandardIntegrityTokenRequest.builder()
                    .setRequestHash(requestHash)
                    .build()
            )
        ).token()
    }
}
