FLOATING AI TUTOR - ANDROID SOURCE PROJECT
Version 1.1 release preparation

PROJECT
- Package ID: com.example.floatingaitutor
- Android 10+ (API 29+), JDK 17, Android Gradle Plugin 8.7.3
- Debug APK is for local device/UI testing.
- Release AAB requires an owner-created upload keystore and Play Console setup.

INCLUDED IN THIS SOURCE
- AES-GCM encrypted Worker URL and tutor token using Android Keystore.
- Migration and deletion of old plaintext SharedPreferences values.
- HTTPS-only endpoint validation; cleartext traffic disabled.
- Bearer-token authentication to the Cloudflare Worker.
- Google Play immediate in-app update flow.
- Release signing configuration using environment variables.
- Version code 2 / version name 1.1.
- GitHub Actions workflow for debug APK and signed release AAB.

BACKEND SECURITY NOTE
- This build does not use Google Play Integrity. The Worker authenticates requests using the Bearer token only.
- This is suitable for testing, not strong protection against unauthorized clients.
