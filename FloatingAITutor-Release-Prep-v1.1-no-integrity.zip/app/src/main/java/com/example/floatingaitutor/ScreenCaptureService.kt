package com.example.floatingaitutor

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Base64
import android.view.WindowManager
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private val executor = Executors.newSingleThreadExecutor()
    private var captured = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showNotification()
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("projectionData", Intent::class.java)
        else intent?.getParcelableExtra("projectionData")

        if (data == null || resultCode != Activity.RESULT_OK) {
            publish("Screen capture permission was not received."); stopSelf(); return START_NOT_STICKY
        }
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, Handler(Looper.getMainLooper()))

            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            reader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, android.graphics.PixelFormat.RGBA_8888, 2)
            display = projection!!.createVirtualDisplay("TutorCapture", metrics.widthPixels, metrics.heightPixels,
                metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)

            reader!!.setOnImageAvailableListener({ source ->
                if (captured) return@setOnImageAvailableListener
                val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
                captured = true
                try {
                    val plane = image.planes[0]
                    val pixelStride = plane.pixelStride
                    val rowPadding = plane.rowStride - pixelStride * image.width
                    val paddedWidth = image.width + rowPadding / pixelStride
                    val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
                    padded.copyPixelsFromBuffer(plane.buffer)
                    val bitmap = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
                    padded.recycle()
                    image.close()
                    sendImage(bitmap)
                    bitmap.recycle()
                } catch (e: Exception) {
                    try { image.close() } catch (_: Exception) {}
                    publish("Could not read screenshot: ${e.message}"); stopSelf()
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
            publish("Capture failed: ${e.message}"); stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun showNotification() {
        val id = "tutor_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(id, "Tutor screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, id).setContentTitle("Floating AI Tutor")
                .setContentText("Reading the screen you approved").setSmallIcon(android.R.drawable.ic_menu_view).build()
            else Notification.Builder(this).setContentTitle("Floating AI Tutor")
                .setContentText("Reading the screen you approved").setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(41, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(41, notification)
    }

    private fun sendImage(bitmap: Bitmap) {
        executor.execute {
            try {
                val secureConfig = SecureConfigStore(this@ScreenCaptureService)
                val endpoint = secureConfig.endpoint()
                val token = secureConfig.token()
                if (endpoint.isBlank() || token.isBlank()) {
                    publish("Open the app and save the Worker URL and tutor access token first.")
                    stopSelf(); return@execute
                }
                val bytes = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 70, bytes)
                val imageData = "data:image/jpeg;base64," + Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP)
                val question = "Read the visible screen and explain the main question step by step."
                val payload = JSONObject()
                    .put("question", question)
                    .put("image", imageData)

                SecureConfigStore.validateHttpsEndpoint(endpoint)
                val conn = URL(endpoint).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 90000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("Authorization", "Bearer $token")
                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream.bufferedReader().use { it.readText() }
                val response = JSONObject(text)
                val answer = if (code in 200..299) response.optString("answer", "No answer returned.")
                    else "Server error ($code): ${response.optString("error", text)}"
                publish(answer)
                conn.disconnect()
            } catch (e: Exception) {
                publish("Connection error: ${e.message}")
            } finally { stopSelf() }
        }
    }

    private fun publish(answer: String) {
        sendBroadcast(Intent("com.example.floatingaitutor.RESULT").putExtra("answer", answer))
    }
    override fun onDestroy() {
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        executor.shutdown()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
