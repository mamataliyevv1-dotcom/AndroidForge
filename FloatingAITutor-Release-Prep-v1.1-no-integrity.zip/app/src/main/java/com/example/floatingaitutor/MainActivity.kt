package com.example.floatingaitutor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability

class MainActivity : Activity() {
    private lateinit var endpoint: EditText
    private lateinit var token: EditText
    private val secureConfig by lazy { SecureConfigStore(this) }
    private lateinit var appUpdateManager: AppUpdateManager
    private val updateRequestCode = 4107

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        appUpdateManager = AppUpdateManagerFactory.create(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        layout.addView(TextView(this).apply { text = "Floating AI Tutor"; textSize = 26f })
        layout.addView(TextView(this).apply {
            text = "Enter your Cloudflare Worker URL and private tutor access token. Do not enter your OpenAI API key here."
            textSize = 14f
            setPadding(0, 12, 0, 18)
        })
        endpoint = EditText(this).apply {
            hint = "https://your-worker.workers.dev"
            setSingleLine(true)
            setText(secureConfig.endpoint())
        }
        layout.addView(endpoint)
        token = EditText(this).apply {
            hint = "Tutor access token"
            setSingleLine(true)
            inputType = 129
            setText(secureConfig.token())
        }
        layout.addView(token)
        layout.addView(Button(this).apply {
            text = "Save connection"
            setOnClickListener {
                try {
                    saveConfig()
                    Toast.makeText(this@MainActivity, "Secure connection details saved.", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, e.message ?: "Invalid connection details.", Toast.LENGTH_LONG).show()
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "Enable floating tutor"
            setOnClickListener {
                try { saveConfig() } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, e.message ?: "Invalid connection details.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, FloatingOverlayService::class.java))
                    Toast.makeText(this@MainActivity, "Floating tutor enabled.", Toast.LENGTH_LONG).show()
                }
            }
        })
        layout.addView(TextView(this).apply {
            text = "Usage: leave this app, tap the floating panel, approve Android's screen-capture prompt, then wait for the explanation. Android asks for capture permission each time."
            textSize = 13f
            setPadding(0, 18, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }


    override fun onResume() {
        super.onResume()
        if (::appUpdateManager.isInitialized) checkForPlayUpdate()
    }

    private fun checkForPlayUpdate() {
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            val availability = info.updateAvailability()
            val updateAllowed = info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)
            if ((availability == UpdateAvailability.UPDATE_AVAILABLE && updateAllowed) ||
                availability == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                @Suppress("DEPRECATION")
                appUpdateManager.startUpdateFlowForResult(
                    info, this,
                    AppUpdateOptions.newBuilder(AppUpdateType.IMMEDIATE).build(),
                    updateRequestCode
                )
            }
        }.addOnFailureListener {
            // Expected for sideloaded/debug installs: Play In-App Updates need Play distribution.
        }
    }

    private fun saveConfig() {
        val url = SecureConfigStore.validateHttpsEndpoint(endpoint.text.toString())
        val accessToken = token.text.toString().trim()
        require(accessToken.isNotBlank()) { "Tutor access token is required." }
        secureConfig.save(url, accessToken)
    }
}
