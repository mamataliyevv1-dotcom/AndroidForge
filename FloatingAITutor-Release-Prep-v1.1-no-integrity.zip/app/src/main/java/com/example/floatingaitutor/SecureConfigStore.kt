package com.example.floatingaitutor

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.net.URI
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Stores the Worker URL and tutor token encrypted with an AES-GCM key held by Android Keystore. */
class SecureConfigStore(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val legacy = context.getSharedPreferences(LEGACY_PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun save(endpoint: String, token: String) {
        val normalized = validateHttpsEndpoint(endpoint)
        prefs.edit()
            .putString(KEY_ENDPOINT, encrypt(normalized))
            .putString(KEY_TOKEN, encrypt(token.trim()))
            .apply()
        // Remove old plaintext values after the encrypted copy has been written.
        legacy.edit().remove("endpoint").remove("token").apply()
    }

    @Synchronized
    fun endpoint(): String = readEncrypted(KEY_ENDPOINT) ?: migrateLegacy()?.first.orEmpty()

    @Synchronized
    fun token(): String = readEncrypted(KEY_TOKEN) ?: migrateLegacy()?.second.orEmpty()

    @Synchronized
    private fun migrateLegacy(): Pair<String, String>? {
        val oldEndpoint = legacy.getString("endpoint", null) ?: return null
        val oldToken = legacy.getString("token", "").orEmpty()
        return try {
            val normalized = validateHttpsEndpoint(oldEndpoint)
            prefs.edit()
                .putString(KEY_ENDPOINT, encrypt(normalized))
                .putString(KEY_TOKEN, encrypt(oldToken))
                .apply()
            legacy.edit().remove("endpoint").remove("token").apply()
            normalized to oldToken
        } catch (_: Exception) {
            // Do not migrate an insecure or malformed legacy endpoint.
            null
        }
    }

    private fun readEncrypted(key: String): String? {
        val packed = prefs.getString(key, null) ?: return null
        return try {
            val bytes = Base64.decode(packed, Base64.NO_WRAP)
            require(bytes.size > IV_LENGTH)
            val iv = bytes.copyOfRange(0, IV_LENGTH)
            val ciphertext = bytes.copyOfRange(IV_LENGTH, bytes.size)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEY_STORE).apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEY_STORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    companion object {
        private const val PREFS = "tutor_secure_config"
        private const val LEGACY_PREFS = "tutor_config"
        private const val KEY_ENDPOINT = "endpoint_enc"
        private const val KEY_TOKEN = "token_enc"
        private const val KEY_ALIAS = "floating_ai_tutor_config_key"
        private const val ANDROID_KEY_STORE = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_LENGTH = 12

        fun validateHttpsEndpoint(raw: String): String {
            val value = raw.trim().trimEnd('/')
            val uri = URI(value)
            require(uri.scheme.equals("https", ignoreCase = true)) { "Worker URL must use HTTPS." }
            require(!uri.host.isNullOrBlank() && uri.userInfo == null) { "Enter a valid HTTPS Worker URL." }
            require(uri.port == -1 || uri.port == 443) { "Only the standard HTTPS port is allowed." }
            return value
        }
    }
}
