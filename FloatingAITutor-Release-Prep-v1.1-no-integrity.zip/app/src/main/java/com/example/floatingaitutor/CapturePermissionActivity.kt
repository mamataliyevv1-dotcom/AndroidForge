package com.example.floatingaitutor

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast

class CapturePermissionActivity : Activity() {
    private val requestCode = 731
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCode)
    }

    @Deprecated("Activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, ScreenCaptureService::class.java)
                .putExtra("resultCode", resultCode).putExtra("projectionData", data)
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        } else Toast.makeText(this, "Screen capture cancelled.", Toast.LENGTH_SHORT).show()
        finish()
    }
}
