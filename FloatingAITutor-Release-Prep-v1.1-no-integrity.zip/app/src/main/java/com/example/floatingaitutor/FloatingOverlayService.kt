package com.example.floatingaitutor

import android.app.Service
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*

class FloatingOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var answerView: TextView? = null
    private lateinit var receiver: BroadcastReceiver

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                answerView?.text = intent?.getStringExtra("answer") ?: "No answer received."
            }
        }
        val filter = IntentFilter("com.example.floatingaitutor.RESULT")
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(receiver, filter)
    }

    private fun showPanel() {
        val d = resources.displayMetrics.density
        val w = (113 * d).toInt()
        val h = (189 * d).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(7, 7, 7, 7)
            setBackgroundColor(Color.rgb(27, 39, 67))
        }
        box.addView(TextView(this).apply {
            text = "AI TUTOR"; setTextColor(Color.WHITE); textSize = 13f
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, 27))
        box.addView(Button(this).apply {
            text = "TAP TO\nCAPTURE"
            textSize = 11f
            setOnClickListener {
                answerView?.text = "Requesting screen capture…"
                startActivity(Intent(this@FloatingOverlayService, CapturePermissionActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }, LinearLayout.LayoutParams(-1, 62))
        val scroll = ScrollView(this)
        answerView = TextView(this).apply {
            text = "Tap to explain the question on your screen."
            setTextColor(Color.WHITE); textSize = 11f; setPadding(4, 5, 4, 4)
        }
        scroll.addView(answerView)
        box.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(w, h, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END; x = 12; y = 180
        }

        box.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=params.x; sy=params.y; tx=e.rawX; ty=e.rawY; return false }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = sx - (e.rawX-tx).toInt()
                        params.y = sy + (e.rawY-ty).toInt()
                        wm.updateViewLayout(box, params); return true
                    }
                }
                return false
            }
        })
        panel = box
        wm.addView(box, params)
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
